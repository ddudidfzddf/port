import { Block, CommandError, Player, system, TicksPerSecond, world } from '@minecraft/server';

function findChatCommand(chatCommandName) {
    const chatCommandIds = world.getDynamicPropertyIds().filter(prop => prop.startsWith('chatCommand:'));
    if(chatCommandIds.length > 0) {
        const cmdDatas = chatCommandIds.map(id => {
            return {
                id: id,
                data: JSON.parse(world.getDynamicProperty(id))
            }
        });

        return cmdDatas.find(cmdData => cmdData.data.chatCommand.toLowerCase() === chatCommandName);
    }
    return
}

export class ChatCommand {
    constructor(chatCommandName) {
        this.chatCommandName = chatCommandName;
        this.hasData = !!this.getData();
    }

    getId() {
        return findChatCommand(this.chatCommandName.toLowerCase())?.id;
    }

    getData() {
        return findChatCommand(this.chatCommandName.toLowerCase())?.data;
    }
}

export function clearedCooldownMessages(chatCommands) {
    if(chatCommands.length === 0) {
        return '§cThere are currently no chat commands on cooldown.';
    }
    else if(chatCommands.length === 1) {
        return `§aThe cooldown of the §3${chatCommands[0]}§a chat command has been reset.`;
    }
    else {
        const lastChatCommand = chatCommands.pop();
        return `§aThe cooldown of the §3${chatCommands.join(', ')}§a, and §3${lastChatCommand}§a chat commands has been reset.`
    }
}

export function generateId(existingIds) {
    let chatCommandId;
    do {
        const randomNumber = Math.floor(Math.random() * 100000000);
        chatCommandId = 'chatCommand:' + randomNumber.toString().padStart(8, '0');
    } while(existingIds.includes(chatCommandId));
    return chatCommandId;
}

export function getCmdCommand(message) {
    const cmdMessage = message.toLowerCase().trim();
    const cmdCommands = ['create', 'edit', 'delete', 'list', 'resetcd'];

    if(cmdMessage.startsWith('cmd:')) {
        const command = cmdMessage.replace('cmd:', '').trim();
        if(cmdCommands.includes(command)) {
            return command;
        }
        return 'unknown';
    }
    return;
}

export function getTimeFormat(totalTimeInSeconds) {
    const minutes = Math.floor(totalTimeInSeconds / 60);
    const seconds = totalTimeInSeconds % 60;

    const minuteStr = minutes <= 1 ? `${minutes} minute` : `${minutes} minutes`;
    const secondStr = seconds <= 1 ? `${seconds} second` : `${seconds} seconds`;

    if (minutes > 0 && seconds > 0) {
        return `${minutes}m ${seconds}s`;
    } else if (minutes > 0) {
        return minuteStr;
    }
    return secondStr;
}

export function executeCommands(executor, commands) {
    function executeCommand(command) {
        return new Promise((resolve, reject) => {
            system.runTimeout(() => {
                try {
                    const source = executor instanceof Block ? executor.dimension : executor;
                    const isSuccess = source.runCommand(command.command).successCount > 0;
                    resolve(isSuccess);
                }
                catch (error) {
                    reject(error);
                }
            }, TicksPerSecond * command.delay);
        });
    }

    async function iterateCommands(commands, index = 0) {
        while(executor.isValid() && index < commands.length) {
            try {
                const isSuccess = await executeCommand(commands[index]);
                if(commands[index + 1]?.condition === 1 && !isSuccess) break;
            }
            catch(error) {
                if(executor.isValid() && error instanceof CommandError) {
                    const cmdError = error.toString().replace('CommandError: ', '');
                    if(executor instanceof Player) {
                        executor.sendMessage(`§3Error found in Command Line ${index + 1}: §c${cmdError}`);
                    }
                    if(commands[index + 1]?.condition === 0) {
                        index++;
                        continue;
                    }
                }
                else {
                    throw error;
                }
                break;
            }
            index++
        }
    }

    iterateCommands(commands);
}
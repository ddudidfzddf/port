import { TicksPerSecond, system, world, ScriptEventSource } from '@minecraft/server';
import { clearedCooldownMessages, executeCommands, getCmdCommand, getTimeFormat, ChatCommand } from './utils';
import { chatCommandList, createChatCommand, noChatCommandForm } from './forms';

const activeCooldown = []
const playerBeingShown = {};

system.runInterval(() => {
    if(activeCooldown.length > 0) {
        for(let i = 0; i < activeCooldown.length; i++) {
            const cooldownData = activeCooldown[i];
            const remainingTicks = cooldownData.cooldownTicks--;

            if(remainingTicks === 0) {
                activeCooldown.splice(i, 1);
            }
        }
        world.setDynamicProperty('activeCooldown', JSON.stringify(activeCooldown));
    }
});

world.afterEvents.worldInitialize.subscribe(() => {
    const onCurrentCooldowns = world.getDynamicPropertyIds().find(id => id === 'activeCooldown');

    if(onCurrentCooldowns) {
        const cooldowns = JSON.parse(world.getDynamicProperty(onCurrentCooldowns));
        activeCooldown.push(...cooldowns);
    }
});

import('@minecraft/server-ui').then((ui) => {
    let [userBusy, userClosed] = Object.values(ui.FormCancelationReason), formData;
    for (formData of [ui.ActionFormData, ui.MessageFormData, ui.ModalFormData]) {
        const formShow = Object.getOwnPropertyDescriptor(formData.prototype, "show").value;
        Object.defineProperty(formData.prototype, "show", {
            value: function (player, persistent = false, trials = 100) {
                const show = formShow.bind(this, player);
                if (player.id in playerBeingShown) return;
                playerBeingShown[player.id] = true;
                return new Promise(async(resolve) => {
                    let result;
                    do {
                        result = await show();
                        if(!trials-- || persistent && result.cancelationReason === userClosed) return delete playerBeingShown[player.id];
                    }
                    while (result.cancelationReason === userBusy);
                    delete playerBeingShown[player.id];
                    resolve(result);
                })
            }
        });
    }
});

world.afterEvents.playerLeave.subscribe(({playerId}) => delete playerBeingShown[playerId]);

world.beforeEvents.chatSend.subscribe((data) => {
    const {message, sender} = data;
    const chatCommandIds = world.getDynamicPropertyIds().filter(id => id.startsWith('chatCommand:'));
    const cmdMessage = getCmdCommand(message);

    if(cmdMessage) {
        data.cancel = true;
        system.run(() => {
            if(sender.isOp() || sender.hasTag('operator')) {
                switch(cmdMessage) {
                    case 'create':
                        createChatCommand(sender);
                    break;
                    case 'edit':
                        if(chatCommandIds.length === 0) {
                            noChatCommandForm(sender);
                        }
                        else {
                            chatCommandList(sender, chatCommandIds, 'Edit');
                        }
                    break;
                    case 'delete':
                        if(chatCommandIds.length === 0) {
                            sender.sendMessage('§cNo chat command was found. Deletion is not possible.');
                        }
                        else {
                            chatCommandList(sender, chatCommandIds, 'Delete');
                        }
                    break;
                    case 'list':
                        const commandList = [
                            '§acmd: create§r = §bCreate a new custom chat commands.',
                            '§acmd: edit§r = §bEdit an existing chat commands.',
                            '§acmd: delete§r = §bDelete an existing chat commands.',
                            '§acmd: resetcd§r = §bReset the cooldown of all chat commands that are currently in cooldown.'
                        ]

                        for(const command of commandList) {
                            sender.sendMessage(command);
                        }
                    break;
                    case 'resetcd':
                        const cooldownDatas = activeCooldown.filter(cdData => cdData.playerId === sender.id);
                        const chatCommands = cooldownDatas.map(cmd => JSON.parse(world.getDynamicProperty(cmd.chatCommandId)).chatCommand);

                        for(let i = activeCooldown.length - 1; i >= 0; i--) {
                            if(cooldownDatas.indexOf(activeCooldown[i]) !== -1) {
                                activeCooldown.splice(i, 1);
                            }
                        }
                        sender.sendMessage(clearedCooldownMessages(chatCommands));
                    break;
                    default:
                        sender.sendMessage(`§cUnknown cmd command: §3${message}§c. Please use §acmd: list§c to check all available commands`);
                    break;
                }
            }
            else {
                if(cmdMessage === 'unknown') {
                    sender.sendMessage(`§cUnknown cmd command: ${message}. Please check that the command exists and that you have permission to use it.`);
                }
                else {
                    sender.sendMessage('§cYou don\'t have permission to use this cmd command.');
                }
            }
        });
    }
    else {
        const ChatCommandData = new ChatCommand(message);

        if(!ChatCommandData.hasData) return;
        const {chatCommand, caseSensitive, cooldown, onCooldownMessage, tagsPermission, commands} = ChatCommandData.getData();
        const isMatched = caseSensitive ? message === chatCommand : message.toLowerCase() === chatCommand.toLowerCase();
        const tagsArray = tagsPermission?.split(',')?.map(tag => tag.trim());

        if(!isMatched) return;
        const hasPermission = tagsPermission ? sender.getTags().some(tag => tagsArray.includes(tag)) || sender.isOp() : true;
        data.cancel = true;
        if(hasPermission) {
            system.run(() => {
                if(cooldown > 0) {
                    const chatCommandId = ChatCommandData.getId()
                    const index = activeCooldown.findIndex(cdData => cdData.playerId === sender.id && cdData.chatCommandId === chatCommandId);
                    const cooldownTicksRemaining = activeCooldown[index]?.cooldownTicks ?? 0;
                    if(cooldownTicksRemaining === 0) {
                        executeCommands(sender, commands);
                        activeCooldown.push({
                            playerId: sender.id,
                            chatCommandId: chatCommandId,
                            cooldownTicks: cooldown * TicksPerSecond
                        });
                    }
                    else {
                        const remainingTime = getTimeFormat(Math.floor(cooldownTicksRemaining / TicksPerSecond));
                        sender.sendMessage((onCooldownMessage || '§cChat Command is in cooldown. Please try again in @cooldown.').replace(/@cooldown/gi, remainingTime));
                    }
                }
                else {
                    executeCommands(sender, commands);
                }
            });
        }
        else {
            sender.sendMessage('§cYou don\'t have permission to use this chat command.');
        }
        return;
    }
});

system.afterEvents.scriptEventReceive.subscribe(data => {
    const {id, message, initiator, sourceType, sourceBlock, sourceEntity} = data;
    
    if(id !== 'cmd:run_chat_command') return;
    const chatCommand = new ChatCommand(message);
    if(chatCommand.getId()) {
        const getExecutor = () => {
            switch(sourceType) {
                case ScriptEventSource.Block:
                    return sourceBlock;
                case ScriptEventSource.Entity:
                    return sourceEntity
                case ScriptEventSource.NPCDialogue:
                    return initiator;
            }
        }
        const commands = chatCommand.getData().commands;
        executeCommands(getExecutor(), commands);
    }
}, {namespaces: ['cmd']});
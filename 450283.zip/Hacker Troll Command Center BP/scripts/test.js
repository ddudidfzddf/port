import { Player, world } from '@minecraft/server';
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";
world.events.beforeItemUse.subscribe(event => {
    if (event.item.typeId === "minecraft:stick") {
        let form = new ActionFormData()
        const source = event.source;
        form.title('test')
        form.button('Hi')
        form.show(source).then(r => {
            if (r.selection === 0) source.runCommandAsync('say hi')
        })
    }
})

import { Player, world } from '@minecraft/server';
import { ModalFormData, ActionFormData } from "@minecraft/server-ui";
world.events.beforeItemUse.subscribe(event => {
    if (event.item.typeId === "mcd:mcd_stick") {
        let form = new ActionFormData()
        const source = event.source;
        form.title("Hacker Troll Command Center")
        form.body("\nSelect a Category\n\n")
        form.button('Hacked Gear')
        form.button('Commands')
        form.button('Effects')
        form.button('Actionbar Messages')
        form.button('Troll Commands')
        form.show(source).then(r => {
            if (r.selection === 0) {
                let form = new ActionFormData()
                form.title('Hacked Gear')
                form.button('Level 25 Armor')
                form.button('Level 25 Tools')
                form.button('Level 25 Extras')
                form.button('Level 100 Armor')
                form.button('Level 100 Tools')
                form.button('Level 100 Extras')
                form.show(source).then(r => {
                    if (r.selection === 0) {
                        let form = new ModalFormData()
                        form.title('Level 25 Armor Distribution')
                        form.dropdown('Recipient', ['Self', 'All', 'Random', 'Nearest', 'Farthest'], 0)
                        form.show(source).then(r => {
                            if (r.formValues[0] === 0) source.runCommandAsync('execute as @s at @s run structure load e25_armor ~ ~ ~')
                            if (r.formValues[0] === 1) source.runCommandAsync('execute as @a at @s run structure load e25_armor ~ ~ ~')
                            if (r.formValues[0] === 2) source.runCommandAsync('execute as @r at @s run structure load e25_armor ~ ~ ~')
                            if (r.formValues[0] === 3) source.runCommandAsync('tag @s add omit', 'execute as @a[tag=!omit,c=1] at @s run structure load e25_armor ~ ~ ~', 'tag @s remove omit')
                            if (r.formValues[0] === 4) source.runCommandAsync('execute as @a[c=-1] at @s run structure load e25_armor ~ ~ ~')
                        })
                    }
                    if (r.selection === 1) {
                        let form = new ModalFormData()
                        form.title('Level 25 tools Distribution')
                        form.dropdown('Recipient', ['Self', 'All', 'Random', 'Nearest', 'Farthest'], 0)
                        form.show(source).then(r => {
                            if (r.formValues[0] === 0) source.runCommandAsync('execute as @s at @s run structure load e25_tools ~ ~ ~')
                            if (r.formValues[0] === 1) source.runCommandAsync('execute as @a at @s run structure load e25_tools ~ ~ ~')
                            if (r.formValues[0] === 2) source.runCommandAsync('execute as @r at @s run structure load e25_tools ~ ~ ~')
                            if (r.formValues[0] === 3) source.runCommandAsync('tag @s add omit', 'execute as @a[tag=!omit,c=1] at @s run structure load e25_tools ~ ~ ~', 'tag @s remove omit')
                            if (r.formValues[0] === 4) source.runCommandAsync('execute as @a[c=-1] at @s run structure load e25_tools ~ ~ ~')
                        })
                    }
                    if (r.selection === 2) {
                        let form = new ModalFormData()
                        form.title('Level 25 Extras Distribution')
                        form.dropdown('Recipient', ['Self', 'All', 'Random', 'Nearest', 'Farthest'], 0)
                        form.show(source).then(r => {
                            if (r.formValues[0] === 0) source.runCommandAsync('execute as @s at @s run structure load e25_extras ~ ~ ~')
                            if (r.formValues[0] === 1) source.runCommandAsync('execute as @a at @s run structure load e25_extras ~ ~ ~')
                            if (r.formValues[0] === 2) source.runCommandAsync('execute as @r at @s run structure load e25_extras ~ ~ ~')
                            if (r.formValues[0] === 3) source.runCommandAsync('tag @s add omit', 'execute as @a[tag=!omit,c=1] at @s run structure load e25_extras ~ ~ ~', 'tag @s remove omit')
                            if (r.formValues[0] === 4) source.runCommandAsync('execute as @a[c=-1] at @s run structure load e25_extras ~ ~ ~')
                        })
                    }
                    if (r.selection === 3) {
                        let form = new ModalFormData()
                        form.title('Level 100 Armor Distribution')
                        form.dropdown('Recipient', ['Self', 'All', 'Random', 'Nearest', 'Farthest'], 0)
                        form.show(source).then(r => {
                            if (r.formValues[0] === 0) source.runCommandAsync('execute as @s at @s run structure load e100_armor ~ ~ ~')
                            if (r.formValues[0] === 1) source.runCommandAsync('execute as @a at @s run structure load e100_armor ~ ~ ~')
                            if (r.formValues[0] === 2) source.runCommandAsync('execute as @r at @s run structure load e100_armor ~ ~ ~')
                            if (r.formValues[0] === 3) source.runCommandAsync('tag @s add omit', 'execute as @a[tag=!omit,c=1] at @s run structure load e100_armor ~ ~ ~', 'tag @s remove omit')
                            if (r.formValues[0] === 4) source.runCommandAsync('execute as @a[c=-1] at @s run structure load e100_armor ~ ~ ~')
                        })
                    }
                    if (r.selection === 4) {
                        let form = new ModalFormData()
                        form.title('Level 100 tools Distribution')
                        form.dropdown('Recipient', ['Self', 'All', 'Random', 'Nearest', 'Farthest'], 0)
                        form.show(source).then(r => {
                            if (r.formValues[0] === 0) source.runCommandAsync('execute as @s at @s run structure load e100_tools ~ ~ ~')
                            if (r.formValues[0] === 1) source.runCommandAsync('execute as @a at @s run structure load e100_tools ~ ~ ~')
                            if (r.formValues[0] === 2) source.runCommandAsync('execute as @r at @s run structure load e100_tools ~ ~ ~')
                            if (r.formValues[0] === 3) source.runCommandAsync('tag @s add omit', 'execute as @a[tag=!omit,c=1] at @s run structure load e100_tools ~ ~ ~', 'tag @s remove omit')
                            if (r.formValues[0] === 4) source.runCommandAsync('execute as @a[c=-1] at @s run structure load e100_tools ~ ~ ~')
                        })
                    }
                    if (r.selection === 5) {
                        let form = new ModalFormData()
                        form.title('Level 100 Extras Distribution')
                        form.dropdown('Recipient', ['Self', 'All', 'Random', 'Nearest', 'Farthest'], 0)
                        form.show(source).then(r => {
                            if (r.formValues[0] === 0) source.runCommandAsync('execute as @s at @s run structure load e100_extras ~ ~ ~')
                            if (r.formValues[0] === 1) source.runCommandAsync('execute as @a at @s run structure load e100_extras ~ ~ ~')
                            if (r.formValues[0] === 2) source.runCommandAsync('execute as @r at @s run structure load e100_extras ~ ~ ~')
                            if (r.formValues[0] === 3) source.runCommandAsync('tag @s add omit', 'execute as @a[tag=!omit,c=1] at @s run structure load e100_extras ~ ~ ~', 'tag @s remove omit')
                            if (r.formValues[0] === 4) source.runCommandAsync('execute as @a[c=-1] at @s run structure load e100_extras ~ ~ ~')
                        })
                    }
                })
            }
            if (r.selection === 1) {
                let form = new ActionFormData()
                form.title('Commands')
                form.body('\nSelect a command for more options\n\n')
                form.button('Creative/Survival Mode')
                form.button('Teleport')
                form.button('Kill')
                form.button('Custom Command')
                form.show(source).then(r => {
                    if (r.selection === 0) {
                        let form = new ActionFormData()
                        form.title('Creative Mode Toggles')
                        form.body('\n\n')
                        if (source.hasTag('creative_s')) form.button('Toggle Self to Survival')
                        if (!source.hasTag('creative_s')) form.button('Toggle Self to Creative')
                        if (source.hasTag('creative_a')) form.button('Toggle All to Survival')
                        if (!source.hasTag('creative_a')) form.button('Toggle All to Creative')

                        form.show(source).then((response) => {
                            if (response.selection === 0) {
                                source.runCommandAsync('function creative_s_on')
                            }
                            if (response.selection === 1) {
                                source.runCommandAsync('function creative_a_on')
                            }

                        })


                    }
                    if (r.selection === 1) {
                        let form = new ActionFormData()
                        form.title('Teleport Options')
                        form.button('TP Yourself')
                        form.button('TP Other Players')
                        form.show(source).then(r => {
                            if (r.selection === 0) {
                                let form = new ModalFormData()
                                form.title('TP to Players')
                                form.dropdown('Destination', ['Nearest Player', 'Furthest Player', 'Random Player', 'Specific Player'], 0)
                                form.show(source).then(r => {
                                    if (r.formValues[0] === 0) source.runCommandAsync('tp @s @p')
                                    if (r.formValues[0] === 1) source.runCommandAsync('tp @s @a[c=-1]')
                                    if (r.formValues[0] === 2) source.runCommandAsync('tp @s @r')
                                    if (r.formValues[0] === 3) {
                                        let form = new ModalFormData()
                                        form.title('Enter Players Name')
                                        form.textField('Players Name', 'Players Name')
                                        form.show(source).then(r => {
                                            let destination = r.formValues[0]
                                            let command = 'tp @s ' + destination
                                            source.runCommandAsync(command)
                                        })
                                    }

                                })
                            }
                            if (r.selection === 1) {
                                let form = new ModalFormData()
                                form.title('TP Players to You')
                                form.dropdown('Target', ['All Players', 'Random Player', 'Nearest Player', 'Furthest Player', 'Specific Player'], 0)
                                form.show(source).then(r => {
                                    if (r.formValues[0] === 0) source.runCommandAsync('tp @a @s')
                                    if (r.formValues[0] === 1) source.runCommandAsync('tp @r @s')
                                    if (r.formValues[0] === 2) source.runCommandAsync('tp @p @s')
                                    if (r.formValues[0] === 3) source.runCommandAsync('tp @a[c=-1] @s')
                                    if (r.formValues[0] === 4) {
                                        let form = new ModalFormData()
                                        form.title('Enter Players Name')
                                        form.textField('Players Name', 'Players Name')
                                        form.show(source).then(r => {
                                            let target = r.formValues[0]
                                            let command = 'tp ' + target + ' @s'
                                            source.runCommandAsync(command)
                                        })

                                    }
                                })
                            }
                        })
                    }
                    if (r.selection === 2) {
                        let form = new ModalFormData()
                        form.title('Kill Options')
                        form.dropdown('Target', ['All Players & Mobs', 'All Players', 'Specific Player'], 0)
                        form.show(source).then(r => {
                            if (r.formValues[0] === 0) source.runCommandAsync('kill @e')
                            if (r.formValues[0] === 1) source.runCommandAsync('kill @a')
                            if (r.formValues[0] === 2) {
                                let form = new ModalFormData()
                                form.title('Enter Players Name')
                                form.textField('Players Name', 'Players Name')
                                form.show(source).then(r => {
                                    let target = r.formValues[0]
                                    let command = 'kill ' + target
                                    source.runCommandAsync(command)
                                })

                            }

                        })
                    }
                    if (r.selection === 3) {
                        let form = new ModalFormData()
                        form.title('Enter Custom Command')
                        form.textField('Command', 'Command')
                        form.show(source).then(r => {
                            let command = r.formValues[0]
                            source.runCommandAsync(command)
                        })
                    }
                })
            }
            if (r.selection === 2) {
                let form = new ModalFormData()
                form.title('Effect Options')
                form.textField("Target (e.g. '@a','@s',or player name)", 'Target')
                form.dropdown('Effect', ['Absorption', 'Haste', 'Health Boost', 'Invisibility', 'Jump Boost', 'Night Vision', 'Resistance', 'Slow Falling', 'Speed'], 0)
                form.slider('Duration (seconds)', 30, 600, 30, 30)
                form.slider('Effect Strength', 1, 10, 1, 1)
                form.show(source).then(r => {
                    let target = r.formValues[0]
                    let duration = r.formValues[2]
                    let strength = r.formValues[3]
                    if (r.formValues[1] === 0) source.runCommandAsync('effect ' + target + ' absorption ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 1) source.runCommandAsync('effect ' + target + ' haste ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 2) source.runCommandAsync('effect ' + target + ' health_boost ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 3) source.runCommandAsync('effect ' + target + ' invisibility ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 4) source.runCommandAsync('effect ' + target + ' jump_boost ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 5) source.runCommandAsync('effect ' + target + ' night_vision ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 6) source.runCommandAsync('effect ' + target + ' resistance ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 7) source.runCommandAsync('effect ' + target + ' slow_falling ' + duration + ' ' + strength + ' true')
                    if (r.formValues[1] === 8) source.runCommandAsync('effect ' + target + ' speed ' + duration + ' ' + strength + ' true')

                })
            }
            if (r.selection === 3) {
                let form = new ModalFormData()
                form.title('Actionbar Message')
                form.textField('Name to Display for Sender', 'Name to Display for Sender')
                form.textField('Send to', 'Send to')
                form.textField('Message', 'Message')
                form.show(source).then(r => {
                    let sender = r.formValues[0]
                    let to = r.formValues[1]
                    let message = r.formValues[2]
                    let command2 = 'title ' + to + ' actionbar ' + sender + ': ' + message
                    source.runCommandAsync(command2)
                })
            }
            if (r.selection === 4) {
                let form = new ActionFormData()
                form.title('Troll Commands')
                form.body('\n\n')
                form.button('Monsters')
                form.button('Environment')
                form.button('Miscellaneous')
                form.show(source).then(r => {
                    if (r.selection === 0) {
                        let form = new ActionFormData()
                        form.title('Monsters')
                        form.body('\n\nSelect which mob you would like to troll another player with\n\n')
                        form.button('Witch')
                        form.button('Enderman')
                        form.button('Creeper')
                        form.button('Warden')
                        form.show(source).then(r => {
                            if (r.selection === 0) {
                                let form = new ActionFormData()
                                form.title('Troll Target')
                                form.body('\n\n3 Witches will be spawned around the target')
                                form.button('All Players')
                                form.button('Random Player')
                                form.button('Specific Player')
                                form.show(source).then(r => {
                                    if (r.selection === 0) {
                                        source.runCommandAsync('execute as @a at @s run summon witch ~-12 ~1 ~6')
                                        source.runCommandAsync('execute as @a at @s run summon witch ~9 ~1 ~-14')
                                        source.runCommandAsync('execute as @a at @s run summon witch ~-9 ~1 ~-9')
                                    }
                                    if (r.selection === 1) {
                                        source.runCommandAsync('execute as @r at @s run summon witch ~-12 ~1 ~6')
                                        source.runCommandAsync('execute as @r at @s run summon witch ~9 ~1 ~-14')
                                        source.runCommandAsync('execute as @r at @s run summon witch ~-9 ~1 ~-9')

                                    }
                                    if (r.selection === 2) {
                                        let form = new ModalFormData()
                                        form.title('Enter Name of Target')
                                        form.textField('Player Name', 'Player Name')
                                        form.show(source).then(r => {
                                            let target = r.formValues[0]
                                            let command3 = 'execute as ' + target + ' at @s run summon witch ~-12 ~1 ~6'
                                            let command4 = 'execute as ' + target + ' at @s run summon witch ~9 ~1 ~-14'
                                            let command5 = 'execute as ' + target + ' at @s run summon witch ~-9 ~1 ~-9'
                                            source.runCommandAsync(command3)
                                            source.runCommandAsync(command4)
                                            source.runCommandAsync(command5)
                                        })
                                    }
                                })
                            }
                            if (r.selection === 1) {
                                let form = new ActionFormData()
                                form.title('Troll Target')
                                form.body('\n\n5 Enderman will be spawned around the target')
                                form.button('All Players')
                                form.button('Random Player')
                                form.button('Specific Player')
                                form.show(source).then(r => {
                                    if (r.selection === 0) {
                                        source.runCommandAsync('execute as @a at @s run summon enderman ~-12 ~1 ~6')
                                        source.runCommandAsync('execute as @a at @s run summon enderman ~9 ~1 ~-14')
                                        source.runCommandAsync('execute as @a at @s run summon enderman ~-9 ~1 ~-9')
                                        source.runCommandAsync('execute as @a at @s run summon enderman ~-4 ~1 ~14')
                                        source.runCommandAsync('execute as @a at @s run summon enderman ~5 ~1 ~19')

                                    }
                                    if (r.selection === 1) {
                                        source.runCommandAsync('execute as @r at @s run summon enderman ~-12 ~1 ~6')
                                        source.runCommandAsync('execute as @r at @s run summon enderman ~9 ~1 ~-14')
                                        source.runCommandAsync('execute as @r at @s run summon enderman ~-9 ~1 ~-9')
                                        source.runCommandAsync('execute as @r at @s run summon enderman ~-4 ~1 ~14')
                                        source.runCommandAsync('execute as @r at @s run summon enderman ~5 ~1 ~19')
                                    }
                                    if (r.selection === 2) {
                                        let form = new ModalFormData()
                                        form.title('Enter Name of Target')
                                        form.textField('Player Name', 'Player Name')
                                        form.show(source).then(r => {
                                            let target = r.formValues[0]
                                            let command3 = 'execute as ' + target + ' at @s run summon enderman ~-12 ~1 ~6'
                                            let command4 = 'execute as ' + target + ' at @s run summon enderman ~9 ~1 ~-14'
                                            let command5 = 'execute as ' + target + ' at @s run summon enderman ~-9 ~1 ~-9'
                                            let command6 = 'execute as ' + target + ' at @s run summon enderman ~-4 ~1 ~14'
                                            let command7 = 'execute as ' + target + ' at @s run summon enderman ~5 ~1 ~19'
                                            source.runCommandAsync(command3)
                                            source.runCommandAsync(command4)
                                            source.runCommandAsync(command5)
                                            source.runCommandAsync(command6)
                                            source.runCommandAsync(command7)
                                        })
                                    }
                                })
                            }
                            if (r.selection === 2) {
                                let form = new ActionFormData()
                                form.title('Troll Target')
                                form.body('\n\n5 Creeper will be spawned around the target')
                                form.button('All Players')
                                form.button('Random Player')
                                form.button('Specific Player')
                                form.show(source).then(r => {
                                    if (r.selection === 0) {
                                        source.runCommandAsync('execute as @a at @s run summon creeper ~-12 ~1 ~6')
                                        source.runCommandAsync('execute as @a at @s run summon creeper ~9 ~1 ~-14')
                                        source.runCommandAsync('execute as @a at @s run summon creeper ~-9 ~1 ~-9')
                                        source.runCommandAsync('execute as @a at @s run summon creeper ~-4 ~1 ~14')
                                        source.runCommandAsync('execute as @a at @s run summon creeper ~5 ~1 ~19')

                                    }
                                    if (r.selection === 1) {
                                        source.runCommandAsync('execute as @r at @s run summon creeper ~-12 ~1 ~6')
                                        source.runCommandAsync('execute as @r at @s run summon creeper ~9 ~1 ~-14')
                                        source.runCommandAsync('execute as @r at @s run summon creeper ~-9 ~1 ~-9')
                                        source.runCommandAsync('execute as @r at @s run summon creeper ~-4 ~1 ~14')
                                        source.runCommandAsync('execute as @r at @s run summon creeper ~5 ~1 ~19')
                                    }
                                    if (r.selection === 2) {
                                        let form = new ModalFormData()
                                        form.title('Enter Name of Target')
                                        form.textField('Player Name', 'Player Name')
                                        form.show(source).then(r => {
                                            let target = r.formValues[0]
                                            let command3 = 'execute as ' + target + ' at @s run summon creeper ~-12 ~1 ~6'
                                            let command4 = 'execute as ' + target + ' at @s run summon creeper ~9 ~1 ~-14'
                                            let command5 = 'execute as ' + target + ' at @s run summon creeper ~-9 ~1 ~-9'
                                            let command6 = 'execute as ' + target + ' at @s run summon creeper ~-4 ~1 ~14'
                                            let command7 = 'execute as ' + target + ' at @s run summon creeper ~5 ~1 ~19'
                                            source.runCommandAsync(command3)
                                            source.runCommandAsync(command4)
                                            source.runCommandAsync(command5)
                                            source.runCommandAsync(command6)
                                            source.runCommandAsync(command7)
                                        })
                                    }
                                })
                            }
                            if (r.selection === 3) {
                                let form = new ActionFormData()
                                form.title('Troll Target')
                                form.body('\n\n1 Warden will be spawned around the target')
                                form.button('All Players')
                                form.button('Random Player')
                                form.button('Specific Player')
                                form.show(source).then(r => {
                                    if (r.selection === 0) {
                                        source.runCommandAsync('execute as @a at @s run summon warden ~-12 ~1 ~6')
                                    }
                                    if (r.selection === 1) {
                                        source.runCommandAsync('execute as @r at @s run summon warden ~-12 ~1 ~6')

                                    }
                                    if (r.selection === 2) {
                                        let form = new ModalFormData()
                                        form.title('Enter Name of Target')
                                        form.textField('Player Name', 'Player Name')
                                        form.show(source).then(r => {
                                            let target = r.formValues[0]
                                            let command3 = 'execute as ' + target + ' at @s run summon warden ~-12 ~1 ~6'

                                            source.runCommandAsync(command3)

                                        })
                                    }
                                })
                            }

                        })
                    }
                    if (r.selection === 1) {
                        let form = new ActionFormData()
                        form.title('Environment')
                        form.body('\n\n')
                        form.button('Hole in Ground')
                        form.button('Disappearing Ores')
                        form.show(source).then(r => {
                            if (r.selection === 0) {
                                let form = new ActionFormData()
                                form.title('Troll Target')
                                form.body('\n\nHole will be place directly below targeted players')
                                form.button('All Players')
                                form.button('Random Player')
                                form.button('Specific Player')
                                form.show(source).then(r => {
                                    if (r.selection === 0) {
                                        source.runCommandAsync('tag @s add omit')
                                        source.runCommandAsync('execute as @a[tag=!omit] at @s run fill ~-2 ~ ~-2 ~2 ~-20 ~2 air 0')
                                        source.runCommandAsync('tag @s remove omit')
                                    }
                                    if (r.selection === 1) {
                                        source.runCommandAsync('tag @s add omit')
                                        source.runCommandAsync('execute as @r[tag=!omit] at @s run fill ~-2 ~ ~-2 ~2 ~-20 ~2 air 0')
                                        source.runCommandAsync('tag @s remove omit')
                                    }
                                    if (r.selection === 2) {
                                        let form = new ModalFormData()
                                        form.title('Enter Name of Target')
                                        form.textField('Player Name', 'Player Name')
                                        form.show(source).then(r => {
                                            let command = 'execute as ' + r.formValues[0] + ' at @s run fill ~-2 ~ ~-2 ~2 ~-20 ~2 air 0'
                                            source.runCommandAsync(command)
                                        })
                                    }

                                })

                            }
                            if (r.selection === 1) {
                                let form = new ActionFormData()
                                form.title('Disappearing Ores')
                                form.body('\n\nDo you want to add this effect to player(s) or remove effect?')
                                form.button('Add Effect')
                                form.button('Remove Effect')
                                form.show(source).then(r => {
                                    if (r.selection === 0) {
                                        let form = new ModalFormData()
                                        form.title('Troll Target')
                                        form.textField('Player Name or Selector', 'Player Name or Selector')
                                        form.show(source).then(r => {
                                            let target = r.formValues[0]
                                            let command = 'execute as ' + target + ' at @s run tag @s add no_ore'
                                            source.runCommandAsync(command)
                                        })
                                    }
                                    if (r.selection === 1) {
                                        source.runCommandAsync('tag @a remove no_ore')
                                    }
                                })
                            }
                        })
                    }
                })
            }
        })
    }
})



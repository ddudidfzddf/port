import * as server from '@minecraft/server'
import { world } from '@minecraft/server';
import { ActionFormData, ModalFormData, MessageFormData } from '@minecraft/server-ui'
world.beforeEvents.chatSend.subscribe((eventData) => {
    const player = eventData.sender;
    const x = player.getDynamicProperty(`x`);
    const y = player.getDynamicProperty(`y`);
    const z = player.getDynamicProperty(`z`);
    switch (eventData.message) {
        case '!sethome':
            eventData.cancel = true;
            player.setDynamicProperty(`x`, player.location.x)
            player.setDynamicProperty(`y`, player.location.y)
            player.setDynamicProperty(`z`, player.location.z)
            player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§pYou set your Home to: §r(${Math.round(player.getDynamicProperty(`x`))} ${Math.round(player.getDynamicProperty(`y`))} ${Math.round(player.getDynamicProperty(`z`))})"}]}`)
            player.runCommandAsync(`tag @s add HomeSet`)
            break;
        case '!home':
            eventData.cancel = true;
            if (player.hasTag("HomeSet")) {
                let previousx = player.location.x
                let previousy = player.location.y
                let previousz = player.location.z
                player.runCommandAsync(`tp @s ${x} ${y} ${z}`)
                player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§pYou have teleported Home!"}]}`)
                player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§pYour previous coordinates were:§r (${Math.round(previousx)} ${Math.round(previousy)} ${Math.round(previousz)})"}]}`)
            } else {
                player.runCommandAsync(`tellraw @s {"rawtext":[{"text":"§pYou do not have a Home set!"}]}`)
            }
            break;
        default: break;
    }
});
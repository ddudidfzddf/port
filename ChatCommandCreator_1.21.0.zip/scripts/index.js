import { TicksPerSecond, system, world } from '@minecraft/server';
import { clearedCooldownMessages, getCmdCommand, getTimeFormat } from './utils';
import { chatCommandList, createChatCommand, noChatCommandForm } from './forms';

const activeCooldown = []
const playerBeingShown = {};

system.runInterval(() => {
    if(activeCooldown.length > 0) {
        for(let i = 0; i < activeCooldown.length; i++) {
            const cooldownData = activeCooldown[i];
            const remainingTicks = cooldownData.cooldownTicks--;

            if(remainingTicks === 0) {
                activeCooldown.splice(i, 1);
            }
        }
        world.setDynamicProperty('activeCooldown', JSON.stringify(activeCooldown));
    }
});

world.afterEvents.worldInitialize.subscribe(() => {
    const onCurrentCooldowns = world.getDynamicPropertyIds().find(id => id === 'activeCooldown');

    if(onCurrentCooldowns) {
        const cooldowns = JSON.parse(world.getDynamicProperty(onCurrentCooldowns));
        activeCooldown.push(...cooldowns);
    }
});

import('@minecraft/server-ui').then((ui) => {
    let [userBusy, userClosed] = Object.values(ui.FormCancelationReason), formData;
    for (formData of [ui.ActionFormData, ui.MessageFormData, ui.ModalFormData]) {
        const formShow = Object.getOwnPropertyDescriptor(formData.prototype, "show").value;
        Object.defineProperty(formData.prototype, "show", {
            value: function (player, persistent = false, trials = 100) {
                const show = formShow.bind(this, player);
                if (player.id in playerBeingShown) return;
                playerBeingShown[player.id] = true;
                return new Promise(async(resolve) => {
                    let result;
                    do {
                        result = await show();
                        if(!trials-- || persistent && result.cancelationReason === userClosed) return delete playerBeingShown[player.id];
                    }
                    while (result.cancelationReason === userBusy);
                    delete playerBeingShown[player.id];
                    resolve(result);
                })
            }
        });
    }
});

world.afterEvents.playerLeave.subscribe(({playerId}) => delete playerBeingShown[playerId]);

world.beforeEvents.chatSend.subscribe((data) => {
    const {message, sender} = data;
    const chatCommandIds = world.getDynamicPropertyIds().filter(id => id.startsWith('chatCommand:'));
    const cmdMessage = getCmdCommand(message);

    if(cmdMessage) {
        data.cancel = true;
        system.run(() => {
            if(sender.isOp() || sender.hasTag('operator')) {
                switch(cmdMessage) {
                    case 'create':
                        createChatCommand(sender, {});
                    break;
                    case 'edit':
                        if(chatCommandIds.length === 0) {
                            noChatCommandForm(sender);
                        }
                        else {
                            chatCommandList(sender, chatCommandIds, 'Edit');
                        }
                    break;
                    case 'delete':
                        if(chatCommandIds.length === 0) {
                            sender.sendMessage('§cNo chat command was found. Deletion is not possible.');
                        }
                        else {
                            chatCommandList(sender, chatCommandIds, 'Delete');
                        }
                    break;
                    case 'list':
                        const commandList = [
                            '§acmd: create§r = §bCreate a new custom chat commands.',
                            '§acmd: edit§r = §bEdit an existing chat commands.',
                            '§acmd: delete§r = §bDelete an existing chat commands.',
                            '§acmd: resetcd§r = §bReset the cooldown of all chat commands that are currently in cooldown.'
                        ]

                        for(const command of commandList) {
                            sender.sendMessage(command);
                        }
                    break;
                    case 'resetcd':
                        const cooldownDatas = activeCooldown.filter(cdData => cdData.playerId === sender.id);
                        const chatCommands = cooldownDatas.map(cmd => JSON.parse(world.getDynamicProperty(cmd.chatCommandId)).chatCommand);

                        for(let i = activeCooldown.length - 1; i >= 0; i--) {
                            if(cooldownDatas.indexOf(activeCooldown[i]) !== -1) {
                                activeCooldown.splice(i, 1);
                            }
                        }
                        sender.sendMessage(clearedCooldownMessages(chatCommands));
                    break;
                    default:
                        sender.sendMessage(`§cUnknown cmd command: §3${message}§c. Please use §acmd: list§c to check all available commands`);
                    break;
                }
            }
            else {
                if(cmdMessage === 'unknown') {
                    sender.sendMessage(`§cUnknown cmd command: ${message}. Please check that the command exists and that you have permission to use it.`);
                }
                else {
                    sender.sendMessage('§cYou don\'t have permission to use this cmd command.');
                }
            }
        });
    }
    else {
        chatCommandIds.forEach((chatCommandId) => {
            const {chatCommand, caseSensitive, cooldown, onCooldownMessage, tagsPermission, commands} = JSON.parse(world.getDynamicProperty(chatCommandId));
            const chatMessage = new RegExp('^' + message.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '$', caseSensitive ? undefined : 'i');
            const tagsArray = tagsPermission?.split(',')?.map(tag => tag.trim());

            if(chatMessage.test(chatCommand)) {
                const hasPermission = tagsPermission ? sender.getTags().some(tag => tagsArray.includes(tag)) || sender.isOp() : true;
                data.cancel = true;
                if(hasPermission) {
                    system.run(() => {
                        if(cooldown > 0) {
                            const index = activeCooldown.findIndex(cdData => cdData.playerId === sender.id && cdData.chatCommandId === chatCommandId);
                            const cooldownTicksRemaining = activeCooldown[index]?.cooldownTicks ?? 0;
                            if(cooldownTicksRemaining === 0) {
                                iterateCommands(commands);
                                activeCooldown.push({
                                    playerId: sender.id,
                                    chatCommandId: chatCommandId,
                                    cooldownTicks: cooldown * TicksPerSecond
                                });
                            }
                            else {
                                const remainingTime = getTimeFormat(Math.floor(cooldownTicksRemaining / TicksPerSecond));
                                sender.sendMessage((onCooldownMessage || '§cChat Command is in cooldown. Please try again in @cooldown.').replace(/@cooldown/gi, remainingTime));
                            }
                        }
                        else {
                            iterateCommands(commands);
                        }
                    });
                }
                else {
                    sender.sendMessage('§cYou don\'t have permission to use this chat command.');
                }
                return;
            }
        });
    }

    function iterateCommands(commands, index = 0) {
        if(sender.isValid() && commands.length > index) {
            executeCommand(commands, index).then(isSuccess => {
                if(commands[index + 1]?.condition === 1) {
                    if(isSuccess) {
                        iterateCommands(commands, ++index);
                    }
                }
                else {
                    iterateCommands(commands, ++index);
                }
            }).catch(error => {
                if(sender.isValid()) {
                    const cmdError = error.toString().replace('CommandError: ', '');
                    sender.sendMessage(`§3Error found in Command Line ${++index}: §c${cmdError}`);
                }
            });
        }
    }

    function executeCommand(commands, index) {
        return new Promise((resolve, reject) => {
            system.runTimeout(() => {
                try {
                    const isSuccess = sender.runCommand(commands[index].command).successCount > 0;
                    resolve(isSuccess);
                } catch(error) {
                    reject(error);
                }
            }, TicksPerSecond * commands[index].delay);
        });
    }
});
import { world } from '@minecraft/server';
import { ActionFormData, MessageFormData, ModalFormData } from '@minecraft/server-ui';
import { getTimeFormat, generateId } from './utils';

function chatCommandList(player, chatCommandIds, actionType) {
    const cmdList = new ActionFormData()
        .title(`${actionType} Chat Commands`)
        .body(`Select Chat Command to ${actionType}:`)

    for(const chatCommandId of chatCommandIds) {
        const {chatCommand} = JSON.parse(world.getDynamicProperty(chatCommandId));
        cmdList.button(chatCommand);
    }

    cmdList.show(player).then(result => {
        chatCommandIds.forEach((chatCommandId, i) => {
            if(result.selection === i) {
                const chatCommandData = JSON.parse(world.getDynamicProperty(chatCommandId));
                switch(actionType) {
                    case 'Edit':
                        createChatCommand(player, chatCommandData, chatCommandId);
                    break;
                    case 'Delete':
                        const {chatCommand} = chatCommandData;
                        const confirmDelete = new MessageFormData()
                            .title(`Delete '${chatCommand}' chat command?`)
                            .body(`You initiated to delete §a${chatCommand}§r chat command. This action cannot be undone and will result in the permanent loss of the chat command. Are you sure you want to proceed?`)
                            .button1('Cancel')
                            .button2('Confirm Delete')

                        confirmDelete.show(player).then(result => {
                            if(result.selection) {
                                world.setDynamicProperty(chatCommandId, undefined);
                                player.sendMessage(`§bThe §a${chatCommand} §bchat command has been deleted.`);
                            }
                            else {
                                chatCommandList(player, chatCommandIds, actionType);
                            }
                        });
                    break;
                }
            }
        });
    });
}

function createChatCommand(player, defaultData, chatCommandId) {
    const actionType = chatCommandId ? 'Edit' : 'Create';
    const create = new ModalFormData()
        .title(actionType === 'Create' ? 'Chat Command Creator' : 'Edit Chat Command')
        .textField('Chat Command:', 'A text to chat to execute command', defaultData?.chatCommand)
        .toggle('Case Sensitive', defaultData?.caseSensitive)
        .textField('Cooldown in seconds: (Optional)', 'A waiting time before it can use again', defaultData?.cooldown ? defaultData.cooldown.toString() : undefined)
        .textField('On Cooldown Message: (Optional)', 'Type @cooldown to display\nremaining cooldown time', defaultData?.onCooldownMessage)
        .textField('Tags Permission: (Optional)', 'Mutiple tags separated by comma', defaultData?.tagsPermission)
        .submitButton('Next')

    create.show(player).then(result => {
        const chatCommandIds = world.getDynamicPropertyIds().filter(id => id.startsWith('chatCommand:'));
        if(result.canceled) {
            if(actionType === 'Edit') {
                chatCommandList(player, chatCommandIds, actionType);
            }
        }
        else {
            const resultData = result.formValues.map(value => typeof value === 'string' ? value.trim() : value);
            const [chatCommand, caseSensitive, cooldown, onCooldownMessage, tagsPermission] = resultData;
            const canBeUse = function(userInputCmd) {
                const commandIdsToCheck = !!chatCommandId ? chatCommandIds.filter(id => id !== chatCommandId) : chatCommandIds;
                const chatCommandDatas = commandIdsToCheck.map(id => JSON.parse(world.getDynamicProperty(id)));
                return chatCommandDatas.every(data => data.chatCommand.toLowerCase() !== userInputCmd.toLowerCase()); 
            }

            if(!chatCommand) {
                player.sendMessage('§cChat Command field is required.');
            }
            else if(chatCommand.length < 4) {
                player.sendMessage('§cChat command must have at least 4 characters.');
            }
            else if(chatCommand.length > 20) {
                player.sendMessage('§cChat command cannot exceed 20 characters.');
            }
            else if(chatCommand.startsWith('/')) {
                player.sendMessage('§cChat command cannot start with slash (/).');
            }
            else if(chatCommand.toLowerCase().startsWith('cmd:')) {
                player.sendMessage('§cChat command cannot start with cmd:');
            }
            else if(!canBeUse(chatCommand)) {
                player.sendMessage('§cThis chat command already exists. Please choose a different name for the new command.');
            }
            else if(cooldown < 0) {
                player.sendMessage('§cCooldown cannot be less than zero');
            }
            else if(isNaN(cooldown)) {
                player.sendMessage('§cCooldown requires numerical value');
            }
            else {
                const chatCommandData = {
                    chatCommand: chatCommand,
                    caseSensitive: caseSensitive,
                    cooldown: Number(cooldown),
                    onCooldownMessage: onCooldownMessage || undefined,
                    tagsPermission: tagsPermission || undefined,
                    commands: defaultData?.commands ?? []
                }

                commandsToExecutePage(player, chatCommandData, chatCommandId);
            }
        }
    });
}

function commandsToExecutePage(player, chatCommandData, chatCommandId) {
    const actionType = chatCommandId ? 'Edit' : 'Create';
    const commandsArray = chatCommandData.commands;
    const numberOfCommands = commandsArray.length;
    const hasCommands = numberOfCommands > 0;
    const hasAddCommandButton = numberOfCommands < 30;
    const commandsList = new ActionFormData();

    commandsList.title('Commands to Execute');
    commandsList.body(hasCommands ? `Commands to execute: (${numberOfCommands} out of 30)` : 'Select add command button to add new command:');

    commandsArray.forEach((cmd, i) => {
        commandsList.button(`Command Line ${i + 1}\n§t/${cmd.command}`);
    });

    if(hasAddCommandButton) {
        commandsList.button('Add Command', 'textures/ui/color_plus');
    }

    if(hasCommands) {
        commandsList.button(actionType === 'Create' ? 'Create Chat Command' : 'Save Changes', 'textures/ui/chat_send');
    }

    commandsList.show(player).then(result => {
        if(result.canceled) {
            createChatCommand(player, chatCommandData, chatCommandId);
        }
        else {
            const selectedIndex = result.selection;
            const getSelectedAction = function(selectedButton) {
                if(selectedButton > numberOfCommands) {
                    if(hasAddCommandButton && hasCommands) {
                        return numberOfCommands + 2 === selectedButton ? 'create' : 'add';
                    }
                    else if(!hasAddCommandButton && hasCommands) {
                        return 'create';
                    }
                    return 'add';
                }
                return 'view';
            }

            switch(getSelectedAction(selectedIndex + 1)) {
                case 'create':
                    delete chatCommandData.commands[0].condition;
                    const chatCommandDataString = JSON.stringify(chatCommandData);

                    if(actionType === 'Create') {
                        const chatCommandIds = world.getDynamicPropertyIds().filter(id => id.startsWith('chatCommand:'));
                        player.sendMessage('§aChat command has been created successfully.');
                        world.setDynamicProperty(generateId(chatCommandIds), chatCommandDataString);
                    }
                    else {
                        player.sendMessage('§aChat command has been edited succcessfully.');
                        world.setDynamicProperty(chatCommandId, chatCommandDataString);
                    }
                break;
                case 'add':
                    commandPageSettings(player, chatCommandData, undefined, chatCommandId);
                break;
                case 'view':
                    const selectedCommand = chatCommandData.commands[selectedIndex];
                    const condition = selectedCommand.condition ? 'Conditional' : 'Unconditional';
                    const delayText = getTimeFormat(selectedCommand.delay) ?? 'No Delay';
                    const bodyText = selectedIndex === 0
                        ? `§aCommand:§r ${selectedCommand.command}\n§aDelay:§r ${delayText}`
                        : `§aCommand:§r ${selectedCommand.command}\n§aDelay:§r ${delayText}\n§aCondition:§r ${condition}`;

                    const viewCommand = new MessageFormData()
                        .title(`Command Line ${selectedIndex + 1}`)
                        .body(bodyText)
                        .button1('Delete Command')
                        .button2('Edit Command')

                    viewCommand.show(player).then(result => {
                        switch(result.selection) {
                            case undefined: //cancel
                                commandsToExecutePage(player, chatCommandData, chatCommandId);
                            break;
                            case 0: //delete
                                chatCommandData.commands.splice(selectedIndex, 1);
                                commandsToExecutePage(player, chatCommandData, chatCommandId);
                            break;
                            case 1: //edit
                                const commandData = chatCommandData.commands[selectedIndex];
                                commandPageSettings(player, chatCommandData, commandData, chatCommandId);
                            break;
                        }
                    });
                break;
            }
        }
    });
}

function commandPageSettings(player, chatCommandData, defaultCommand, chatCommandId) {
    const commandIndex = chatCommandData.commands.map(data => JSON.stringify(data)).indexOf(JSON.stringify(defaultCommand));
    const hasCondition = chatCommandData?.commands?.length > 0;
    const addCommand = new ModalFormData()
        .title('Command Settings')
        .textField('Command:', 'Command to execute', defaultCommand?.command)
        .textField('Delay in seconds: (Optional)', 'A delay time to execute command', defaultCommand?.delay?.toString())
        .submitButton(!!defaultCommand ? 'Save Command' : 'Add Command')

    if(hasCondition && commandIndex !== 0) {
        addCommand.dropdown('Condition:', ['Unconditional', 'Conditional'], defaultCommand?.condition);
    }

    addCommand.show(player).then(result => {
        if(result.canceled) {
            commandsToExecutePage(player, chatCommandData, chatCommandId);
        }
        else {
            const [command, delay, condition] = result.formValues;
            const commandData = {
                command: (command.startsWith('/') ? command.substring(1) : command).trim(),
                delay: Number(delay) || 0,
                condition: condition
            }

            if(!commandData.command) {
                invalidPage({
                    title: 'No Command is inputted',
                    body: 'The command field cannot be empty. Would you like to continue adding a command?'
                }, commandData);
            }
            else if(commandData.delay < 0){
                invalidPage({
                    title: 'Negative value is not allowed',
                    body: 'The delay cannot be a negative value. Please enter a positive value.'
                }, commandData);
            }
            else if(isNaN(delay)) {
                invalidPage({
                    title: 'Delay requires a number',
                    body: `You entered §c${delay}§r in the delay field, which is not a number. Please enter a valid numerical value.`
                }, commandData);
            }
            else {
                commandIndex === -1 ? chatCommandData.commands.push(commandData) : chatCommandData.commands[commandIndex] = commandData;
                commandsToExecutePage(player, chatCommandData, chatCommandId);
            }
        }
    });

    function invalidPage(errorType, commandData) {
        const {title, body} = errorType;
        const invalidInput = new MessageFormData()
            .title(title)
            .body(body)
            .button1('Exit')
            .button2('Continue')

        invalidInput.show(player).then(result => {
            if(result.selection) {
                commandPageSettings(player, chatCommandData, commandData, chatCommandId);
            }
            else {
                commandsToExecutePage(player, chatCommandData, chatCommandId);
            }
        });
    }
}

function noChatCommandForm(player) {
    const noChatCmdForm = new MessageFormData()
        .title('No Chat Command Found')
        .body('No Chat Command was found. To create a new one, please use the §acmd: create§r command or select the "Create Chat Command" button below.')
        .button1('Exit')
        .button2('Create Chat Command')

    noChatCmdForm.show(player).then(result => {
        if(result.selection) {
            createChatCommand(player, {});
        }
    });
}

export { chatCommandList, createChatCommand, noChatCommandForm }
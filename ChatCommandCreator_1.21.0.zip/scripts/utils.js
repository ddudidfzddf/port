function clearedCooldownMessages(chatCommands) {
    if(chatCommands.length === 0) {
        return '§cThere are currently no chat commands on cooldown.';
    }
    else if(chatCommands.length === 1) {
        return `§aThe cooldown of the §3${chatCommands[0]}§a chat command has been reset.`;
    }
    else {
        const lastChatCommand = chatCommands.pop();
        return `§aThe cooldown of the §3${chatCommands.join(', ')}§a, and §3${lastChatCommand}§a chat commands has been reset.`
    }
}

function generateId(existingIds) {
    let chatCommandId;
    do {
        const randomNumber = Math.floor(Math.random() * 100000000);
        chatCommandId = 'chatCommand:' + randomNumber.toString().padStart(8, '0');
    } while(existingIds.includes(chatCommandId));
    return chatCommandId;
}

function getCmdCommand(message) {
    const cmdMessage = message.toLowerCase().trim();
    const cmdCommands = ['create', 'edit', 'delete', 'list', 'resetcd'];

    if(cmdMessage.startsWith('cmd:')) {
        const command = cmdMessage.replace('cmd:', '').trim();
        if(cmdCommands.includes(command)) {
            return command;
        }
        return 'unknown';
    }
    return;
}

function getTimeFormat(totalTimeInSeconds) {
    const minutes = Math.floor(totalTimeInSeconds / 60);
    const seconds = totalTimeInSeconds % 60;

    if(minutes === 0) {
        if(seconds > 0 && seconds <= 1) {
            return `${seconds} second`;
        }
        else if(seconds === 0) {
            return;
        }
        return `${seconds} seconds`;
    }
    else if(seconds === 0) {
        return minutes === 1 ? '1 minute' : `${minutes} minutes`;
    }
    return `${minutes}m ${seconds}s`;
}

export { clearedCooldownMessages, generateId, getCmdCommand, getTimeFormat }
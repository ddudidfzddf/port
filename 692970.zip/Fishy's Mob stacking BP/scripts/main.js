const ignoredTypes = ['minecraft:player', 'minecraft:item', 'minecraft:armor_stand'];
import { world, DynamicPropertiesDefinition, MinecraftEntityTypes, Player, system, Container } from "@minecraft/server";
import { ModalFormData } from "@minecraft/server-ui";

world.beforeEvents.itemUse.subscribe((event) => {
    const itemStack = event.itemStack
    const player = event.source
    if (itemStack.typeId == 'minecraft:name_tag') {
        event.cancel = true
        player.sendMessage('§cYou cant use that')
    }
})
world.beforeEvents.itemUseOn.subscribe((event) => {
    const itemStack = event.itemStack
    const player = event.source
    if (itemStack.typeId == 'minecraft:name_tag') {
        event.cancel = true
        player.sendMessage('§cYou cant use that')
    }
})

function closestSameMods(entity, location) {
    if (entity instanceof Player) return null;
    const typeId = entity.typeId;
    const options = {
        type: typeId,
        location: location,
        maxDistance: 5,
        minDistance: 0.5
    };
    return entity.dimension.getEntities(options);
}

function stackEntities(entity, entitiesAround) {
    const entityNameTag = entity.nameTag;
    let entityNumber = extractNumberFromNameTag(entityNameTag);

    let foundEntityWithNumber = null;
    let sumOfNumbers = entityNumber !== null ? entityNumber : 1;

    for (const nearbyEntity of entitiesAround) {
        const nearbyNumber = extractNumberFromNameTag(nearbyEntity.nameTag);
        if (nearbyNumber !== null) {
            sumOfNumbers += nearbyNumber;
            foundEntityWithNumber = nearbyEntity;
        }
    }

    if (foundEntityWithNumber !== null) {
        const newNumber = sumOfNumbers;
        entity.nameTag = formatNameTag(entityNameTag, newNumber);
        foundEntityWithNumber.teleport({ x: 0, y: -10000, z: 0 });
        foundEntityWithNumber.kill();
    } else if (entityNumber !== null) {
        for (const nearbyEntity of entitiesAround) {
            if (nearbyEntity !== entity) {
                nearbyEntity.teleport({ x: 0, y: -10000, z: 0 });
                nearbyEntity.kill();
                entityNumber++;
            }
        }
        entity.nameTag = formatNameTag(entityNameTag, entityNumber);
    } else {
        for (const nearbyEntity of entitiesAround) {
            nearbyEntity.teleport({ x: 0, y: -10000, z: 0 });
            nearbyEntity.kill();
        }
        entityNumber = 1;
        entity.nameTag = formatNameTag(entityNameTag, entityNumber);
    }
}

function formatNameTag(baseNameTag, number) {
    baseNameTag = String(baseNameTag).replace("(", "").replace(")", "").split(' ')[0]
    return `${baseNameTag} (${number})`;
}

function extractNumberFromNameTag(nameTag) {
    const matches = nameTag.match(/\((\d+)\)/);
    return matches ? parseInt(matches[1]) : null;
}

system.runInterval(() => {
    const overworldEntities = world.getDimension('overworld').getEntities();
    overworldEntities.forEach(entity => {
        if (!entity.isValid()) return
        if (ignoredTypes.includes(entity.typeId)) return;
        if (entity.nameTag === '') {
            entity.nameTag = entity.typeId.split(":")[1];
        }
        const closestEntities = closestSameMods(entity, entity.location);
        if (closestEntities.length > 0) {
            stackEntities(entity, closestEntities);
            entity.dimension.runCommand('kill @e[r=100,x=0,y=-10000,z=0]')
        }
    });
}, 5);

world.afterEvents.entityDie.subscribe((event) => {
    const { deadEntity: entity } = event
    const player = event.damageSource.damagingEntity
    if (!(entity.isValid())) return
    if (event.damageSource.cause == 'suicide') return
    let number = extractNumberFromNameTag(entity.nameTag)
    if (number != null) {
        const newentity = entity.dimension.spawnEntity(entity.typeId, entity.location)
        let newnumber = number - 1
        if (newnumber >= 2) { newentity.nameTag = formatNameTag(entity.nameTag, newnumber) }
        else { newentity.nameTag = newentity.typeId.split(':')[1] }

    }
})
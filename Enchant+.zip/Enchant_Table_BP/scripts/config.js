
export const config = {
    /**
     * here you can decide the price for each enchant level that you add to your item
     */
    xp:5
};

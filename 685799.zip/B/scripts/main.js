import * as Minecraft from '@minecraft/server'

let version = "§b1.0.0"
//记录玩家死亡点、死亡维度和家的位置
let playerDead = {}
let playerHome = {}
let playerDeadDimension = {}
let playerTips = {}

//记录维度
const dimensions = [Minecraft.world.getDimension("overworld"), Minecraft.world.getDimension("nether"), Minecraft.world.getDimension("the end")]
const showDimensions = ['主世界', '地狱', '末地']

//订阅玩家死亡事件
Minecraft.world.afterEvents.entityDie.subscribe(die => {
     //一些基础变量
     let player = die.deadEntity
     let xyz = player.location
     let id = player.typeId
     let playerName = player.name
     let getDimension = showDimensions[dimensions.indexOf(player.dimension)]
     //记录如果玩家没有死亡位置
     if (!(playerDead in [playerName])) {
          playerDead[playerName] = "没有记录死亡位置"
     }
     //设定死亡的维度默认为主世界
     if (!(playerDeadDimension in [playerName])) {
          playerDeadDimension[playerName] = "主世界"
     }
     //如果ID是玩家
     if (id == "minecraft:player") {
          //获取地狱维度
          if (getDimension == "地狱") {
               playerDeadDimension[playerName] = "地狱"
               Minecraft.system.run(() => {
                    playerDead[playerName] = `${xyz.x} ${xyz.y} ${xyz.z}`
               })
          }
          //获取末地维度
          else if (getDimension == "末地") {
               playerDeadDimension[playerName] = "末地"
               Minecraft.system.run(() => {
                    playerDead[playerName] = `${xyz.x} ${xyz.y} ${xyz.z}`
               })
          }
          //都不是的话则默认为主世界
          else {
               playerDeadDimension[playerName] = "主世界"
               Minecraft.system.run(() => {
                    playerDead[playerName] = `${xyz.x} ${xyz.y} ${xyz.z}`
               })
          }
     }
})

//订阅聊天栏信息
Minecraft.world.beforeEvents.chatSend.subscribe(system => {
     let text = system.message
     let player = system.sender
     let playerName = player.name
     let xyz = player.location
     let entity = player.id
     let getDimension = showDimensions[dimensions.indexOf(player.dimension)]
     if (!(playerName in playerHome)) {
          playerHome[playerName] = "没有记录家的位置"
     }

     if (/#back/i.test(text) == true) {
          system.cancel = true
          Minecraft.system.run(() => {
               if (!(playerName in playerDead)) {
                    player.sendMessage({
                         translate: "xxr.backcommand.no_record_dead"
                    })
               } else {
                    if (playerDeadDimension[playerName] == "地狱") {
                         player.runCommand(`execute as ${playerName} at ${playerName} in nether run tp ${playerName} ${playerDead[playerName]}`)
                    } else if (playerDeadDimension[playerName] == "末地") {
                         player.runCommand(`execute as ${playerName} at ${playerName} in the_end run tp ${playerName} ${playerDead[playerName]}`)
                    } else {
                         player.runCommand(`execute as ${playerName} at ${playerName} in overworld run tp ${playerName} ${playerDead[playerName]}`)
                    }
               }
          })
     }

     if (/#setHome/i.test(text) == true) {
          system.cancel = true
          Minecraft.system.run(() => {
               if (!(getDimension == "主世界")) {
                    player.sendMessage({
                         translate: "xxr.backcommand.no_in_overworld"
                    })
               } else {
                    playerHome[playerName] = `${xyz.x} ${xyz.y} ${xyz.z}`
                    player.sendMessage({
                         translate: "xxr.backcommand.record_home"
                    })
                    player.sendMessage({
                    translate: parseInt(xyz.x) + ' ' + parseInt(xyz.y) + ' ' + parseInt(xyz.z)
               })
               }
          })
     }

     if (/#home/i.test(text) == true) {
          system.cancel = true
          Minecraft.system.run(() => {
               if (playerHome[playerName] === "没有记录家的位置") {
                    player.sendMessage({
                         translate: "§c您没有记录家的位置"
                    })
               } else {
                    player.runCommand(`execute as ${playerName} at ${playerName} in overworld run tp ${playerName} ${playerHome[playerName]}`)
               }
          })
     }

     if (/#removehome|#deletehome/i.test(text) == true) {
          system.cancel = true
          Minecraft.system.run(() => {
               if (playerHome[playerName] === "没有记录家的位置") {
                    player.sendMessage({
                         translate: "xxr.backcommand.no_record_home"
                    })
               } else {
                    playerHome[playerName] = "没有记录家的位置"
                    player.sendMessage({
                         translate: "xxr.backcommand.remove_home"
                    })
               }
          })
     }

     if (/#help/i.test(text) == true) {
          system.cancel = true
          Minecraft.system.run(() => {
               player.sendMessage({
                    translate: "xxr.backcommand.help_I"
               })
               player.sendMessage({
                    translate: "xxr.backcommand.help_II"
               })
               player.sendMessage({
                    translate: "xxr.backcommand.help_III"
               })
               player.sendMessage({
                    translate: "xxr.backcommand.help_IV"
               })
               player.sendMessage({
                    translate: "xxr.backcommand.help_V"
               })
               player.sendMessage({
                    translate: "xxr.backcommand.help_VI"
               })
          })
          let entity = new player()
          entity.remove("minecraft:slime")
     }

})

Minecraft.system.runInterval(() => {
     //遍历所有玩家
     Minecraft.world.getAllPlayers()
          .forEach((player) => {
          let playerName = player.name
          if (!([playerName] in playerTips)) {
               playerTips[playerName] = false
          }
          if (playerTips[playerName] == false) {
               player.sendMessage({
                    translate: "xxr.backcommand.tips_I"
               })
               player.sendMessage({
                    translate: ""
               })
               player.sendMessage({
                    translate: "xxr.backcommand.tips_II"
               })
               player.sendMessage({
                    translate: ""
               })
               player.sendMessage({
                    translate: "xxr.backcommand.tips_III"
               })
               player.sendMessage({
                    translate: ""
               })
               player.sendMessage({
                    translate: "xxr.backcommand.tips_IV"
               })
               player.sendMessage({
                    translate: version
               })
               playerTips[playerName] = true
          }
     })
},20 * 15)
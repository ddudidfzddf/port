Argent created this behaviour pack, which was initially made available on DL,
It is forbidden to modify the bundle or distribute it again with its files altered.

- No credit is necessary; you are free to use this in your map.
- You may provide the download link in your department of posts and share the link to other users.
- Reuploading the pack to a website that does not link to the original DL page is not permitted.
- You are not permitted to claim ownership of the behavior pack.

If these conditions are not met, we are free to ask for a takedown.

Thank You <3 - Argent